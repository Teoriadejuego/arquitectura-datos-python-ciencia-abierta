# Plantilla mínima de proyecto de investigación

Esta carpeta separa decisiones, datos, código, manuscrito y publicación. Cópiela al iniciar cada proyecto y cambie el nombre de la copia. La regla operativa es simple: el dato original no se edita; toda transformación queda en código; solo se publica lo que puede compartirse.

## Recorrido recomendado

1. Defina la pregunta y el protocolo en `02_protocolo/`.
2. Deposite los archivos recibidos, sin modificarlos, en `03_datos/00_raw/`.
3. Mantenga identificadores y material sensible en `03_datos/01_restringidos/`, fuera de Git.
4. Genere `03_datos/02_analiticos/` exclusivamente mediante scripts de `04_codigo/`.
5. Exporte a `03_datos/03_publicos/` solo datos revisados para difusión.
6. Escriba el artículo en `05_manuscrito/`; conserve cada envío editorial en `06_envios_revistas/`.
7. Prepare la versión congelada y sus metadatos en `07_publicacion/`.

## Qué se versiona

Sí: protocolo, código, diccionario, metadatos, texto, tablas pequeñas, figuras y datos autorizados para publicación.

No: identificadores, consentimientos firmados, claves, credenciales, datos originales sensibles ni mapas de reidentificación. El archivo `.gitignore` bloquea por defecto las capas `00_raw` y `01_restringidos`, pero esa barrera no sustituye una revisión manual antes de cada `commit`.

## Primer control

```text
git status
git diff --cached
```

Si aparece un archivo que no debería salir del equipo, no continúe. Retírelo del área de preparación con `git restore --staged -- RUTA_DEL_ARCHIVO` y revise `.gitignore`.

## Convención de nombres

Use minúsculas, guiones bajos y fechas ISO: `2026-09-02_tabla_descriptiva.csv`. Evite espacios, tildes y nombres como `final_v3_ahora_si`.

## Archivos de control

- `03_datos/metadatos/diccionario_datos.csv`: definición de variables.
- `CITATION.cff`: instrucciones de citación del paquete.
- `scripts/copiar_pegar_git.txt`: secuencia Git para Windows y macOS.
- `MANIFIESTO_SHA256.txt`: huellas de los archivos incluidos en esta plantilla.

