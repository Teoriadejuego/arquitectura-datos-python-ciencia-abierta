# Manuscrito

Separe texto, tablas, figuras y bibliografía. Siempre que sea posible, genere tablas y figuras mediante código; no las corrija a mano después de exportarlas.

