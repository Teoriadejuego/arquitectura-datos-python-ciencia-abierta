# Envíos a revistas

Cree una subcarpeta por ronda: `R00_preprint`, `R01_revista_aaaa-mm-dd`, `R02_revision_aaaa-mm-dd`. Conserve el manuscrito enviado, anexos, carta, decisión y respuesta a revisores como una unidad cerrada.

