# Publicación

Prepare aquí la versión citable: archivo público, metadatos, licencia, `CITATION.cff`, notas de versión y comprobantes del depósito. Una publicación debe apuntar a un `commit` y una etiqueta concretos.

