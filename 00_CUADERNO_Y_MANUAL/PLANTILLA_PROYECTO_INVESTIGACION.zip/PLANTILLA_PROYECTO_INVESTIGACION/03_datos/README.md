# Capas del dato

`00_raw` conserva la entrada inmutable. `01_restringidos` contiene información sensible o identificable. `02_analiticos` almacena datos transformados para el análisis. `03_publicos` recibe únicamente exportaciones revisadas para difusión. `metadatos` explica las variables, formatos y transformaciones.

