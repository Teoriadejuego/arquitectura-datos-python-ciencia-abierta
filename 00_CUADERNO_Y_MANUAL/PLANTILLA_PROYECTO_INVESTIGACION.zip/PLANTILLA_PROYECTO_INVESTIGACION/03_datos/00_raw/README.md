# Datos originales

Copias exactas de los archivos recibidos. No editar, renombrar ni subir a Git. Registre procedencia, fecha de recepción y huella SHA-256 en la documentación del proyecto.

