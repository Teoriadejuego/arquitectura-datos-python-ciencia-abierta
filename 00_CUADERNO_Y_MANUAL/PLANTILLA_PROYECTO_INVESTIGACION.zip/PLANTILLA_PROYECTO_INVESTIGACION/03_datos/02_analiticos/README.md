# Datos analíticos

Archivos derivados mediante código y listos para calcular resultados. Deben poder regenerarse desde la capa original en un entorno autorizado.

