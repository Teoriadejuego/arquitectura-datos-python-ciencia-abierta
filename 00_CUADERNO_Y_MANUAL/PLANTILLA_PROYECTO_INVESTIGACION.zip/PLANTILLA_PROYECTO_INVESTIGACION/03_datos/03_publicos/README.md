# Datos públicos

Solo material sometido a revisión de privacidad, licencia y documentación. Este directorio define lo que podría incorporarse a GitHub o a un depósito permanente.

