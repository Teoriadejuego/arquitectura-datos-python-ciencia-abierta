# Metadatos

Complete el diccionario antes de analizar. Cada variable necesita definición, tipo, unidad, valores válidos, procedencia, transformación y nivel de acceso.

