# Datos restringidos

Identificadores, textos sensibles, consentimientos o mapas de enlace. Acceso mínimo, almacenamiento cifrado y exclusión permanente de repositorios públicos.

