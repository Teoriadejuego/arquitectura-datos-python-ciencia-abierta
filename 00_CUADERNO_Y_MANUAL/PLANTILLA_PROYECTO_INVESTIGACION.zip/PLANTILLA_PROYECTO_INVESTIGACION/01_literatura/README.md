# Literatura

Guarde aquí la estrategia de búsqueda, la tabla de evidencia, las referencias y, cuando la licencia lo permita, los textos completos. Registre la fecha y la base consultada; no confunda “descargado” con “verificado”.

