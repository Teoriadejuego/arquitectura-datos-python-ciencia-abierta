# Código

Los scripts numerados permiten reconstruir el recorrido del dato. Evite operaciones manuales que no queden descritas aquí.

