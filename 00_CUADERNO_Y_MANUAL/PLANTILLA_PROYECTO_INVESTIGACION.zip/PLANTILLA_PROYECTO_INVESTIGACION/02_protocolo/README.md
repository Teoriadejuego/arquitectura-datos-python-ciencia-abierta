# Protocolo

Esta carpeta reúne decisiones tomadas antes de observar los resultados. Una modificación posterior debe quedar fechada, justificada y versionada.

